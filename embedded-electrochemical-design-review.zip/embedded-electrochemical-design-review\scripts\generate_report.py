#!/usr/bin/env python3
"""Generate the embedded electrochemical design review DOCX from normalized JSON."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
from typing import Any, Iterable

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor

REPORT_NAME = "Recommendations for embedded electrochemical design.docx"
NAVY = "17324D"
TEAL = "087E8B"
LIGHT_BLUE = "EAF3F6"
LIGHT_GRAY = "F2F4F6"
MID_GRAY = "667085"
WHITE = "FFFFFF"
PRIORITY_COLORS = {"P0": "FEE2E2", "P1": "FEF3C7", "P2": "E0F2FE", "P3": "ECFDF3"}


def desktop_dir() -> Path:
    if os.name == "nt":
        try:
            import winreg

            key_path = r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path) as key:
                value, _ = winreg.QueryValueEx(key, "Desktop")
            return Path(os.path.expandvars(value))
        except (OSError, ImportError):
            pass
    candidate = Path.home() / "Desktop"
    return candidate if candidate.exists() else Path.home()


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=90, start=110, bottom=90, end=110) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tr_pr.append(OxmlElement("w:cantSplit"))


def set_table_widths(table, widths_cm: list[float]) -> None:
    table.autofit = False
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths_cm:
        grid_col = OxmlElement("w:gridCol")
        grid_col.set(qn("w:w"), str(int(Cm(width).emu / 635)))
        grid.append(grid_col)
    for row in table.rows:
        for index, width in enumerate(widths_cm):
            if index < len(row.cells):
                row.cells[index].width = Cm(width)


def set_run_font(run, name: str, size: float, bold: bool = False, color: str | None = None) -> None:
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def style_cell(cell, header: bool = False, font_size: float = 8.2) -> None:
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    set_cell_margins(cell)
    if header:
        set_cell_shading(cell, NAVY)
    for paragraph in cell.paragraphs:
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.line_spacing = 1.05
        for run in paragraph.runs:
            set_run_font(run, "Arial", font_size, header, WHITE if header else None)


def add_table(document: Document, headers: list[str], rows: Iterable[Iterable[Any]], widths_cm: list[float]) -> Any:
    table = document.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.style = "Table Grid"
    for index, value in enumerate(headers):
        table.rows[0].cells[index].text = str(value)
        style_cell(table.rows[0].cells[index], header=True)
    set_repeat_table_header(table.rows[0])
    for values in rows:
        row = table.add_row()
        prevent_row_split(row)
        for index, value in enumerate(values):
            row.cells[index].text = "" if value is None else str(value)
            style_cell(row.cells[index])
    set_table_widths(table, widths_cm)
    document.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def add_field(paragraph, instruction: str, placeholder: str = "") -> None:
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = instruction
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = placeholder
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instr, separate, text, end])


def add_hyperlink(paragraph, text: str, url: str) -> None:
    relationship = paragraph.part.relate_to(
        url,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), relationship)
    run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    color = OxmlElement("w:color")
    color.set(qn("w:val"), TEAL)
    underline = OxmlElement("w:u")
    underline.set(qn("w:val"), "single")
    r_pr.extend([color, underline])
    run.append(r_pr)
    node = OxmlElement("w:t")
    node.text = text
    run.append(node)
    hyperlink.append(run)
    paragraph._p.append(hyperlink)


def configure_styles(document: Document) -> None:
    normal = document.styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "SimSun")
    normal.font.size = Pt(10)
    normal.font.color.rgb = RGBColor.from_string("202B33")
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.15

    for name, size, color, before, after in (
        ("Title", 25, NAVY, 0, 12),
        ("Subtitle", 12, MID_GRAY, 0, 8),
        ("Heading 1", 16, NAVY, 16, 7),
        ("Heading 2", 12.5, TEAL, 12, 5),
        ("Heading 3", 10.5, NAVY, 9, 3),
    ):
        style = document.styles[name]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = name != "Subtitle"
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True


def configure_document(document: Document) -> None:
    section = document.sections[0]
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(1.8)
    section.bottom_margin = Cm(1.7)
    section.left_margin = Cm(2.0)
    section.right_margin = Cm(2.0)
    section.header_distance = Cm(0.8)
    section.footer_distance = Cm(0.8)

    header = section.header.paragraphs[0]
    header.text = "Embedded Electrochemical Design Review"
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for run in header.runs:
        set_run_font(run, "Arial", 8, False, MID_GRAY)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run("Page ")
    set_run_font(run, "Arial", 8, False, MID_GRAY)
    add_field(footer, "PAGE", "1")
    run = footer.add_run(" of ")
    set_run_font(run, "Arial", 8, False, MID_GRAY)
    add_field(footer, "NUMPAGES", "1")

    settings = document.settings._element
    update_fields = OxmlElement("w:updateFields")
    update_fields.set(qn("w:val"), "true")
    settings.append(update_fields)


def add_bullets(document: Document, values: Iterable[Any]) -> None:
    for value in values:
        paragraph = document.add_paragraph(style="List Bullet")
        paragraph.add_run(str(value))


def add_status_callout(document: Document, status: str) -> None:
    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(6)
    paragraph.paragraph_format.space_after = Pt(10)
    p_pr = paragraph._p.get_or_add_pPr()
    shading = OxmlElement("w:shd")
    fill = "DCFCE7" if status == "PASS" else "FEE2E2" if status == "FAIL" else "FEF3C7"
    shading.set(qn("w:fill"), fill)
    p_pr.append(shading)
    run = paragraph.add_run(f"Review status: {status or 'NOT STATED'}")
    set_run_font(run, "Arial", 11, True, NAVY)


def add_section_summary(document: Document, heading: str, values: Iterable[Any]) -> None:
    document.add_heading(heading, level=1)
    values = list(values)
    if values:
        for value in values:
            document.add_paragraph(str(value))
    else:
        document.add_paragraph("No evidence was supplied for this section.")


def make_report(data: dict[str, Any], output: Path) -> None:
    document = Document()
    configure_styles(document)
    configure_document(document)
    metadata = data.get("metadata", {})
    status = str(metadata.get("status", "INSUFFICIENT_EVIDENCE")).upper()

    title = document.add_paragraph(style="Title")
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    title.add_run("Recommendations for embedded electrochemical design")
    subtitle = document.add_paragraph(style="Subtitle")
    subtitle.add_run(str(metadata.get("project", "Embedded electrochemical system")))
    add_status_callout(document, status)

    control_rows = [
        ("Document version", metadata.get("version", "1.0")),
        ("Review date", metadata.get("date", dt.date.today().isoformat())),
        ("Prepared by", metadata.get("prepared_by", "Codex")),
        ("Evidence status", status),
        ("Output file", REPORT_NAME),
    ]
    add_table(document, ["Document control", "Value"], control_rows, [4.2, 12.8])

    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(8)
    run = paragraph.add_run("Evidence grades: ")
    set_run_font(run, "Arial", 9, True, NAVY)
    paragraph.add_run("A = multi-source confirmation; B = primary-source derivation; C = nominal estimate; D = unresolved assumption.")

    document.add_page_break()
    document.add_heading("Contents", level=1)
    toc = document.add_paragraph()
    add_field(toc, 'TOC \\o "1-3" \\h \\z \\u', "Update field in Word to populate the table of contents.")
    document.add_page_break()

    add_section_summary(document, "1. Executive Summary", data.get("executive_summary", []))

    document.add_heading("2. Submitted Evidence and Assumptions", level=1)
    inputs = data.get("inputs", [])
    if inputs:
        add_table(
            document,
            ["File", "Type", "Revision", "Status"],
            [(x.get("file"), x.get("type"), x.get("revision"), x.get("status")) for x in inputs],
            [6.2, 3.3, 3.0, 4.5],
        )
    else:
        document.add_paragraph("No input manifest was supplied.")
    document.add_heading("Assumptions", level=2)
    add_bullets(document, data.get("assumptions", ["No assumptions were recorded."]))

    topology = data.get("electrochemical_topology", {})
    document.add_heading("3. Electrochemical Topology and Sign Convention", level=1)
    add_table(
        document,
        ["Item", "Declared value"],
        [
            ("Applied potential", topology.get("potential_convention", "UNRESOLVED")),
            ("Current convention", topology.get("current_convention", "UNRESOLVED")),
        ],
        [5.0, 12.0],
    )
    for item in topology.get("summary", []):
        document.add_paragraph(str(item))

    document.add_heading("4. Component and Datasheet Compliance", level=1)
    components = data.get("component_reviews", [])
    if not components:
        document.add_paragraph("No normalized component reviews were supplied.")
    for component in components:
        label = f"{component.get('refdes', '?')} - {component.get('part', 'Unidentified part')}"
        document.add_heading(label, level=2)
        add_table(
            document,
            ["Package", "Datasheet", "Status"],
            [(component.get("package"), component.get("datasheet"), component.get("status"))],
            [3.4, 9.8, 3.8],
        )
        if component.get("summary"):
            document.add_paragraph(str(component["summary"]))
        pins = component.get("pins", [])
        if pins:
            add_table(
                document,
                ["Pin", "Name", "Connection", "Requirement", "Status", "Citation"],
                [
                    (p.get("pin"), p.get("name"), p.get("connection"), p.get("requirement"), p.get("status"), p.get("citation"))
                    for p in pins
                ],
                [1.0, 1.7, 3.0, 5.5, 1.8, 4.0],
            )

    document.add_heading("5. Power Rails and DC Operating Points", level=1)
    points = data.get("operating_points", [])
    if points:
        add_table(
            document,
            ["Node", "State", "Nominal", "Minimum", "Maximum", "Basis", "Grade"],
            [(p.get("node"), p.get("state"), p.get("nominal"), p.get("minimum"), p.get("maximum"), p.get("basis"), p.get("grade")) for p in points],
            [2.5, 2.2, 2.2, 2.2, 2.2, 3.8, 1.9],
        )
    else:
        document.add_paragraph("No operating-point table was supplied.")

    document.add_heading("6. Signal Chain, Impedance, Gain, and Noise", level=1)
    calculations = data.get("calculations", [])
    if calculations:
        for calculation in calculations:
            document.add_heading(str(calculation.get("name", "Calculation")), level=2)
            formula = document.add_paragraph()
            formula.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = formula.add_run(str(calculation.get("formula", "Formula not recorded")))
            set_run_font(run, "Consolas", 9.5, False, NAVY)
            document.add_paragraph(f"Result: {calculation.get('result', 'UNRESOLVED')}")
            document.add_paragraph(f"Assumptions: {calculation.get('assumptions', 'None recorded')}")
            document.add_paragraph(f"Evidence grade: {calculation.get('grade', 'D')}")
    else:
        document.add_paragraph("No normalized calculations were supplied.")

    document.add_heading("7. UART and BLE Data Integrity", level=1)
    quality = data.get("data_quality", {})
    document.add_paragraph(f"Status: {quality.get('status', 'NOT TESTED')}")
    add_bullets(document, quality.get("summary", ["No data capture was supplied."]))
    metrics = quality.get("metrics", {})
    if metrics:
        add_table(document, ["Metric", "Value"], sorted(metrics.items()), [8.0, 9.0])

    document.add_heading("8. Oscilloscope and Multimeter Measurement Plan", level=1)
    measurements = data.get("measurements", [])
    if measurements:
        add_table(
            document,
            ["Node", "State", "Instrument/setup", "Expected", "Limits", "Status", "Diagnostic meaning"],
            [
                (
                    m.get("node"),
                    m.get("state"),
                    f"{m.get('instrument', '')}: {m.get('setup', '')}",
                    m.get("expected"),
                    m.get("limits"),
                    m.get("pass"),
                    m.get("diagnosis"),
                )
                for m in measurements
            ],
            [1.8, 1.6, 3.3, 2.0, 2.4, 1.6, 4.3],
        )
    else:
        document.add_paragraph("No bench measurement plan was supplied.")

    document.add_heading("9. PCB Layout Review", level=1)
    layout = data.get("layout_findings", [])
    if layout:
        add_table(
            document,
            ["Priority", "Location", "Observation", "Recommendation", "Evidence"],
            [(x.get("priority"), x.get("location"), x.get("observation"), x.get("recommendation"), x.get("citation")) for x in layout],
            [1.5, 2.6, 4.8, 5.2, 2.9],
        )
    else:
        document.add_paragraph("No PCB layout evidence was supplied or normalized.")

    document.add_heading("10. Prioritized Recommendations", level=1)
    recommendations = sorted(data.get("recommendations", []), key=lambda x: (str(x.get("priority", "P9")), str(x.get("id", ""))))
    if not recommendations:
        document.add_paragraph("No recommendations were recorded.")
    for finding in recommendations:
        priority = str(finding.get("priority", "P3"))
        heading = document.add_paragraph()
        p_pr = heading._p.get_or_add_pPr()
        shading = OxmlElement("w:shd")
        shading.set(qn("w:fill"), PRIORITY_COLORS.get(priority, LIGHT_GRAY))
        p_pr.append(shading)
        run = heading.add_run(f"{finding.get('id', priority)} | {finding.get('title', 'Finding')}")
        set_run_font(run, "Arial", 10.5, True, NAVY)
        fields = (
            ("Location", finding.get("location")),
            ("Observation", finding.get("observation")),
            ("Requirement", finding.get("requirement")),
            ("Consequence", finding.get("consequence")),
            ("Recommendation", finding.get("recommendation")),
            ("Verification", finding.get("verification")),
            ("Evidence grade", finding.get("evidence_grade")),
            ("Citations", "; ".join(map(str, finding.get("citations", [])))),
        )
        for label, value in fields:
            if value in (None, ""):
                continue
            paragraph = document.add_paragraph()
            bold = paragraph.add_run(f"{label}: ")
            bold.bold = True
            paragraph.add_run(str(value))

    add_section_summary(document, "11. Unresolved Items and Residual Risk", data.get("unresolved", []))

    document.add_heading("12. References", level=1)
    references = data.get("references", [])
    if references:
        for index, reference in enumerate(references, 1):
            paragraph = document.add_paragraph()
            paragraph.add_run(f"[{index}] {reference.get('title', 'Untitled source')}")
            if reference.get("revision"):
                paragraph.add_run(f", {reference['revision']}")
            if reference.get("accessed"):
                paragraph.add_run(f", accessed {reference['accessed']}")
            if reference.get("url"):
                paragraph.add_run(". ")
                add_hyperlink(paragraph, str(reference["url"]), str(reference["url"]))
    else:
        document.add_paragraph("No references were supplied.")

    document.core_properties.title = "Recommendations for embedded electrochemical design"
    document.core_properties.subject = "Evidence-based electrochemical hardware and data review"
    document.core_properties.author = str(metadata.get("prepared_by", "Codex"))
    document.core_properties.comments = "Generated from normalized review JSON. Verify all unresolved assumptions."

    output.parent.mkdir(parents=True, exist_ok=True)
    document.save(output)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Normalized UTF-8 review JSON")
    parser.add_argument("--output", type=Path, help="DOCX output; defaults to the actual Desktop")
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding="utf-8"))
    output = args.output or (desktop_dir() / REPORT_NAME)
    make_report(data, output)
    print(output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
