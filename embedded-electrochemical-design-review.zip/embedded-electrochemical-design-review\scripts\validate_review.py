#!/usr/bin/env python3
"""Validate the normalized review JSON used by generate_report.py."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

PRIORITIES = {"P0", "P1", "P2", "P3"}
GRADES = {"A", "B", "C", "D"}
STATUSES = {"PASS", "CONDITIONAL", "FAIL", "INSUFFICIENT_EVIDENCE", "UNRESOLVED", "NOT TESTED"}
FINDING_FIELDS = {"id", "priority", "title", "observation", "recommendation", "verification", "evidence_grade"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding="utf-8"))
    errors: list[str] = []
    warnings: list[str] = []

    if not isinstance(data, dict):
        errors.append("top level must be an object")
    metadata = data.get("metadata", {}) if isinstance(data, dict) else {}
    status = str(metadata.get("status", "")).upper()
    if status and status not in STATUSES:
        warnings.append(f"metadata.status is nonstandard: {status}")

    seen: set[str] = set()
    for index, finding in enumerate(data.get("recommendations", [])):
        missing = FINDING_FIELDS - set(finding)
        if missing:
            errors.append(f"recommendations[{index}] missing: {', '.join(sorted(missing))}")
        finding_id = str(finding.get("id", ""))
        if finding_id in seen:
            errors.append(f"duplicate finding id: {finding_id}")
        seen.add(finding_id)
        if finding.get("priority") not in PRIORITIES:
            errors.append(f"{finding_id or index}: invalid priority")
        if finding.get("evidence_grade") not in GRADES:
            errors.append(f"{finding_id or index}: invalid evidence_grade")
        if finding.get("priority") in {"P0", "P1"} and not finding.get("citations"):
            warnings.append(f"{finding_id or index}: P0/P1 has no citation")

    for index, component in enumerate(data.get("component_reviews", [])):
        if not component.get("part"):
            errors.append(f"component_reviews[{index}] has no exact part")
        if not component.get("datasheet"):
            warnings.append(f"component_reviews[{index}] has no datasheet identity")

    result = {"valid": not errors, "errors": errors, "warnings": warnings}
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
