# Potentiostat Logic Constraints

## Contents

1. Definitions
2. Three-electrode invariants
3. Control-loop audit
4. Measurement-method constraints
5. Dummy-cell verification
6. Invalid conclusions

## 1. Definitions

Use the electrochemical convention:

```text
Applied potential = E_WE - E_RE
```

Declare the current sign convention separately. Conventional anodic current is often plotted positive, but TIA polarity and firmware may invert it.

## 2. Three-electrode invariants

- WE is the reaction interface whose potential relative to RE is controlled.
- RE senses solution potential and should carry negligible current.
- CE supplies the current required by the control loop.
- The control amplifier drives CE from the error between command and RE feedback.
- WE current is measured through a TIA or equivalent current-measurement element.
- RE must not be used as the current return path in normal three-electrode operation.
- CE must not be AC-coupled in series when DC electrochemical current is required.
- A capacitor bridging a compensation node and CE is not the same as a capacitor in series with the CE electrode lead.

## 3. Control-loop audit

Trace and label:

1. command source and reference ground;
2. command-to-electrode transfer sign;
3. control-amplifier positive and negative inputs;
4. CE output range and source/sink limit;
5. RE input impedance, bias current, leakage, and protection;
6. WE virtual potential or bias node;
7. TIA feedback network and output polarity;
8. electrode and solution impedance inside the loop;
9. compensation elements and expected phase margin evidence.

Verify the actual electrode potential algebraically. A common architecture gives a form such as:

```text
E_WE-RE = V_WE_bias - V_RE
```

but never assume that relation without tracing the submitted topology.

Check compliance voltage:

```text
V_CE_required = function(E_command, solution drop, electrode overpotentials)
```

Use a range when electrochemical impedances are unknown. Confirm that CE remains inside the amplifier's linear output range at the required current.

## 4. Measurement-method constraints

- LSV: verify monotonic ramp, step size, scan rate, settling, and ADC aperture.
- CV: verify start/vertex/end sequence, direction reversal, cycle indexing, and sign convention.
- CA: verify precondition potential, step edge, settling versus intended transient, and sample timestamps.
- IT: verify constant potential and actual sample interval.
- SWV: define whether amplitude is peak, half-amplitude, or peak-to-peak; verify forward/reverse sample instants and differential sign.
- DPV: define baseline staircase, pulse polarity, pulse width, period, and pre-pulse/pulse sample windows.

For every method, calculate instantaneous minimum and maximum potential. Do not validate only the baseline endpoints.

## 5. Dummy-cell verification

Use a documented passive dummy cell before a real electrochemical cell. Predict its response from the exact topology. At minimum verify:

- command waveform at the DAC/control input;
- RE feedback tracking;
- CE output headroom;
- TIA output polarity and magnitude;
- ADC code conversion;
- settling after steps;
- no sustained oscillation.

Record dummy-cell resistor/capacitor tolerance. Do not compare a capacitive dummy response against a purely resistive prediction.

## 6. Invalid conclusions

- Circuit noise alone does not establish chemical LOD.
- A visible peak alone does not prove analyte identity.
- A nominal DAC voltage does not prove `E_WE-RE` without feedback verification.
- A stable RE voltage does not prove negligible RE current when its input path is wrong.
- A smooth curve does not prove valid data; filtering can hide saturation, packet loss, or wrong scaling.
