#!/usr/bin/env python3
"""Calculate a generic potentiostat analog signal-chain estimate from JSON."""

from __future__ import annotations

import argparse
import cmath
import json
import math
from pathlib import Path
from typing import Any

K_BOLTZMANN = 1.380649e-23


def require_positive(name: str, value: float) -> float:
    if value <= 0:
        raise ValueError(f"{name} must be positive")
    return value


def rss(values: list[float]) -> float:
    return math.sqrt(sum(v * v for v in values))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="UTF-8 JSON input")
    parser.add_argument("--output", type=Path, help="Output JSON; stdout when omitted")
    args = parser.parse_args()

    cfg: dict[str, Any] = json.loads(args.input.read_text(encoding="utf-8"))
    tia = cfg["tia"]
    rf = require_positive("tia.rf_ohm", float(tia["rf_ohm"]))
    cf = max(0.0, float(tia.get("cf_f", 0.0)))
    frequency = max(0.0, float(cfg.get("analysis_frequency_hz", 0.0)))
    bandwidth = require_positive("bandwidth_hz", float(cfg.get("bandwidth_hz", 1.0)))
    temperature_k = float(cfg.get("temperature_c", 25.0)) + 273.15
    if temperature_k <= 0:
        raise ValueError("temperature must be above absolute zero")

    bias = float(cfg.get("bias_v", 0.0))
    out_min = float(tia.get("output_min_v", -math.inf))
    out_max = float(tia.get("output_max_v", math.inf))
    if out_min >= out_max:
        raise ValueError("tia.output_min_v must be below output_max_v")

    zf = complex(rf, 0.0)
    pole_hz = None
    if cf > 0:
        zf = rf / (1.0 + 1j * 2.0 * math.pi * frequency * rf * cf)
        pole_hz = 1.0 / (2.0 * math.pi * rf * cf)

    stages = cfg.get("voltage_gain_stages", [])
    total_voltage_gain = 1.0
    for index, stage in enumerate(stages):
        gain = float(stage.get("gain", 1.0))
        if gain == 0:
            raise ValueError(f"voltage_gain_stages[{index}].gain cannot be zero")
        total_voltage_gain *= gain

    expected_current = cfg.get("expected_current_a")
    expected_tia_output = None
    expected_adc_input = None
    if expected_current is not None:
        expected_tia_output = bias - float(expected_current) * zf
        stage_value = expected_tia_output
        for stage in stages:
            reference = float(stage.get("reference_v", 0.0))
            stage_value = reference + float(stage.get("gain", 1.0)) * (stage_value - reference)
            stage_value += float(stage.get("offset_v", 0.0))
        expected_adc_input = stage_value

    positive_current_limit = None if not math.isfinite(out_min) else (bias - out_min) / rf
    negative_current_limit = None if not math.isfinite(out_max) else -(out_max - bias) / rf

    sqrt_b = math.sqrt(bandwidth)
    resistor_v_noise = math.sqrt(4.0 * K_BOLTZMANN * temperature_k * rf * bandwidth)
    resistor_i_noise = math.sqrt(4.0 * K_BOLTZMANN * temperature_k * bandwidth / rf)
    opamp_en = max(0.0, float(tia.get("opamp_en_v_per_sqrt_hz", 0.0)))
    opamp_in = max(0.0, float(tia.get("opamp_in_a_per_sqrt_hz", 0.0)))
    opamp_i_noise = opamp_in * sqrt_b
    opamp_v_as_i = (opamp_en / abs(zf)) * sqrt_b
    analog_input_i_noise = rss([resistor_i_noise, opamp_i_noise, opamp_v_as_i])

    adc_result: dict[str, Any] | None = None
    adc_i_noise_terms: list[float] = []
    adc = cfg.get("adc")
    if adc:
        bits = int(adc["bits"])
        if not 1 <= bits <= 64:
            raise ValueError("adc.bits must be between 1 and 64")
        adc_min = float(adc["input_min_v"])
        adc_max = float(adc["input_max_v"])
        if adc_min >= adc_max:
            raise ValueError("adc.input_min_v must be below input_max_v")
        span = adc_max - adc_min
        ideal_lsb = span / (2**bits)
        quant_rms = ideal_lsb / math.sqrt(12.0)
        effective_transimpedance = abs(zf * total_voltage_gain)
        adc_i_noise_terms.append(quant_rms / effective_transimpedance)
        adc_noise_rms = max(0.0, float(adc.get("input_noise_rms_v", 0.0)))
        if adc_noise_rms:
            adc_i_noise_terms.append(adc_noise_rms / effective_transimpedance)
        enob = adc.get("enob")
        enob_lsb = None
        if enob is not None:
            enob_lsb = span / (2 ** float(enob))

        ideal_code = None
        saturated = None
        if expected_adc_input is not None:
            adc_v = expected_adc_input.real
            ideal_code = round((adc_v - adc_min) / span * ((2**bits) - 1))
            saturated = not (adc_min <= adc_v <= adc_max)

        adc_result = {
            "input_span_v": span,
            "ideal_lsb_v": ideal_lsb,
            "quantization_rms_v": quant_rms,
            "enob_lsb_v": enob_lsb,
            "expected_ideal_code": ideal_code,
            "expected_input_saturated": saturated,
        }

    total_input_i_noise = rss([analog_input_i_noise, *adc_i_noise_terms])

    uncertainty_terms_pct = [abs(float(v)) for v in cfg.get("independent_gain_uncertainty_pct", [])]
    offset_terms_v = [abs(float(v)) for v in cfg.get("independent_output_offset_uncertainty_v", [])]
    uncertainty = {
        "gain_rss_pct": rss(uncertainty_terms_pct) if uncertainty_terms_pct else None,
        "output_offset_rss_v": rss(offset_terms_v) if offset_terms_v else None,
        "method": "RSS; valid only for independent terms supplied by the reviewer",
    }

    result = {
        "assumptions": [
            "Rf and Cf are parallel feedback elements.",
            "Noise densities are white over the supplied equivalent noise bandwidth.",
            "Op-amp voltage-noise conversion en/|Zf| is a first-order estimate; noise gain and sensor capacitance are not modeled.",
            "ADC code estimate is ideal and uses explicit input_min_v/input_max_v endpoints.",
        ],
        "tia": {
            "rf_ohm": rf,
            "cf_f": cf,
            "analysis_frequency_hz": frequency,
            "feedback_impedance_real_ohm": zf.real,
            "feedback_impedance_imag_ohm": zf.imag,
            "feedback_impedance_magnitude_ohm": abs(zf),
            "feedback_phase_deg": math.degrees(cmath.phase(zf)),
            "pole_hz": pole_hz,
            "positive_current_limit_a": positive_current_limit,
            "negative_current_limit_a": negative_current_limit,
            "expected_output_real_v": None if expected_tia_output is None else expected_tia_output.real,
            "expected_output_imag_v": None if expected_tia_output is None else expected_tia_output.imag,
        },
        "gain": {
            "downstream_voltage_gain": total_voltage_gain,
            "effective_transimpedance_magnitude_v_per_a": abs(zf * total_voltage_gain),
            "expected_adc_input_real_v": None if expected_adc_input is None else expected_adc_input.real,
            "expected_adc_input_imag_v": None if expected_adc_input is None else expected_adc_input.imag,
        },
        "noise": {
            "bandwidth_hz": bandwidth,
            "temperature_k": temperature_k,
            "rf_voltage_noise_rms_v": resistor_v_noise,
            "rf_input_current_noise_rms_a": resistor_i_noise,
            "opamp_current_noise_rms_a": opamp_i_noise,
            "opamp_voltage_as_input_current_noise_rms_a": opamp_v_as_i,
            "analog_input_current_noise_rms_a": analog_input_i_noise,
            "total_input_current_noise_rms_a": total_input_i_noise,
        },
        "adc": adc_result,
        "uncertainty": uncertainty,
    }

    text = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
