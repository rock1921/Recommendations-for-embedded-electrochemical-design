# Word Report Model

## Input schema

`generate_report.py` accepts UTF-8 JSON. Most sections are optional, but `metadata` should include project and review status.

```json
{
  "metadata": {
    "project": "Portable potentiostat review",
    "version": "1.0",
    "date": "2026-07-27",
    "status": "CONDITIONAL",
    "prepared_by": "Codex"
  },
  "executive_summary": ["Summary paragraph."],
  "inputs": [
    {"file": "schematic.pdf", "type": "schematic", "revision": "A", "status": "reviewed"}
  ],
  "assumptions": ["Temperature assumed to be 25 degC."],
  "electrochemical_topology": {
    "potential_convention": "E_WE - E_RE",
    "current_convention": "Anodic current positive",
    "summary": ["Topology description."]
  },
  "component_reviews": [
    {
      "refdes": "U1",
      "part": "Exact MPN",
      "package": "Package",
      "datasheet": "Official document Rev X",
      "status": "CONDITIONAL",
      "summary": "Component summary",
      "pins": [
        {"pin": "1", "name": "IN", "connection": "NET", "requirement": "...", "status": "PASS", "citation": "p. 5"}
      ]
    }
  ],
  "operating_points": [
    {"node": "VBIAS", "state": "idle", "nominal": "1.650 V", "minimum": "1.630 V", "maximum": "1.670 V", "basis": "calculation", "grade": "B"}
  ],
  "calculations": [
    {"name": "TIA full scale", "formula": "I = V/R", "result": "10 uA", "assumptions": "...", "grade": "C"}
  ],
  "data_quality": {
    "status": "PASS",
    "summary": ["No sequence gaps."],
    "metrics": {"valid_frames": 1000, "missing_sequences": 0}
  },
  "measurements": [
    {"node": "VREF", "state": "powered", "instrument": "DMM", "setup": "DCV to AGND", "expected": "2.500 V", "limits": "2.495 to 2.505 V", "pass": "Not tested", "diagnosis": "Out of range indicates reference loading or supply fault."}
  ],
  "layout_findings": [],
  "recommendations": [
    {"id": "P1-001", "priority": "P1", "title": "Example", "location": "U1", "observation": "...", "requirement": "...", "consequence": "...", "recommendation": "...", "verification": "...", "evidence_grade": "B", "citations": ["Datasheet Rev X, p. 5"]}
  ],
  "unresolved": ["Need PCB bottom copper plot."],
  "references": [
    {"title": "Official datasheet", "revision": "Rev X", "url": "https://example.com", "accessed": "2026-07-27"}
  ]
}
```

## Report behavior

- Preserve the language used in the JSON content.
- Keep formulas as text when native equation generation is unavailable.
- Use real Word heading styles so navigation and a TOC can be updated in Word.
- Put detailed pin matrices in landscape only when necessary; otherwise use narrow columns and concise cells.
- Repeat table headers across pages.
- Include page number, document title header, status, filename, generation timestamp, and evidence legend.
- Clearly label incomplete analysis and unresolved assumptions.
- Do not embed raw confidential captures unless the user requests it.

## Filename

The default filename is exactly:

```text
Recommendations for embedded electrochemical design.docx
```

Windows strips trailing periods from filenames; the period in the requested title is represented by the `.docx` extension.
