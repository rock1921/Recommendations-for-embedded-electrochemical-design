#!/usr/bin/env python3
"""Analyze sequence, timing, noise, saturation, and drift in CSV or JSONL data."""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from pathlib import Path
from typing import Any


def percentile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * p
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] * (upper - position) + ordered[upper] * (position - lower)


def load_rows(path: Path, fmt: str) -> list[dict[str, Any]]:
    if fmt == "csv":
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            return list(csv.DictReader(handle))
    rows = []
    for number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        item = json.loads(line)
        if not isinstance(item, dict):
            raise ValueError(f"JSONL line {number} is not an object")
        rows.append(item)
    return rows


def linear_slope(times: list[float], values: list[float]) -> float | None:
    if len(times) < 2:
        return None
    tx = statistics.fmean(times)
    vy = statistics.fmean(values)
    denominator = sum((x - tx) ** 2 for x in times)
    if denominator == 0:
        return None
    return sum((x - tx) * (y - vy) for x, y in zip(times, values)) / denominator


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--format", choices=["csv", "jsonl"], default="csv")
    parser.add_argument("--seq", default="seq", help="Sequence field; empty disables")
    parser.add_argument("--time", default="time_s", help="Time field; empty disables")
    parser.add_argument("--time-scale", type=float, default=1.0, help="Multiply input time by this to obtain seconds")
    parser.add_argument("--value", default="value", help="Numeric sample field")
    parser.add_argument("--seq-modulus", type=int, help="Sequence counter modulus")
    parser.add_argument("--sat-min", type=float)
    parser.add_argument("--sat-max", type=float)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    rows = load_rows(args.input, args.format)
    values: list[float] = []
    times: list[float] = []
    sequences: list[int] = []
    invalid_rows = 0
    for row in rows:
        try:
            values.append(float(row[args.value]))
            if args.time:
                times.append(float(row[args.time]) * args.time_scale)
            if args.seq:
                sequences.append(int(str(row[args.seq]), 0))
        except (KeyError, TypeError, ValueError):
            invalid_rows += 1

    valid_count = len(values)
    if not valid_count:
        raise ValueError("no valid rows")
    if args.time and len(times) != valid_count:
        raise ValueError("some valid value rows have invalid time fields")
    if args.seq and len(sequences) != valid_count:
        raise ValueError("some valid value rows have invalid sequence fields")

    duplicate_seq = missing_seq = out_of_order = 0
    if sequences:
        for previous, current in zip(sequences, sequences[1:]):
            if args.seq_modulus:
                delta = (current - previous) % args.seq_modulus
                if delta == 0:
                    duplicate_seq += 1
                elif delta > args.seq_modulus // 2:
                    out_of_order += 1
                elif delta > 1:
                    missing_seq += delta - 1
            else:
                delta = current - previous
                if delta == 0:
                    duplicate_seq += 1
                elif delta < 0:
                    out_of_order += 1
                elif delta > 1:
                    missing_seq += delta - 1

    intervals = [b - a for a, b in zip(times, times[1:])] if times else []
    positive_intervals = [x for x in intervals if x > 0]
    nonpositive_intervals = len(intervals) - len(positive_intervals)
    median_interval = statistics.median(positive_intervals) if positive_intervals else None
    jitter = [x - median_interval for x in positive_intervals] if median_interval is not None else []

    sat_count = 0
    for value in values:
        if args.sat_min is not None and value <= args.sat_min:
            sat_count += 1
        elif args.sat_max is not None and value >= args.sat_max:
            sat_count += 1

    mean = statistics.fmean(values)
    stdev = statistics.stdev(values) if len(values) > 1 else 0.0
    rms = math.sqrt(statistics.fmean(v * v for v in values))
    result = {
        "input": str(args.input),
        "rows_total": len(rows),
        "rows_valid": valid_count,
        "rows_invalid": invalid_rows,
        "sequence": {
            "enabled": bool(sequences),
            "duplicates": duplicate_seq,
            "missing": missing_seq,
            "out_of_order": out_of_order,
        },
        "timing": {
            "enabled": bool(times),
            "duration_s": (times[-1] - times[0]) if len(times) > 1 else None,
            "median_interval_s": median_interval,
            "effective_rate_hz": (1.0 / median_interval) if median_interval and median_interval > 0 else None,
            "nonpositive_intervals": nonpositive_intervals,
            "jitter_rms_s": math.sqrt(statistics.fmean(x * x for x in jitter)) if jitter else None,
            "jitter_peak_to_peak_s": (max(jitter) - min(jitter)) if jitter else None,
        },
        "signal": {
            "mean": mean,
            "stdev": stdev,
            "rms": rms,
            "minimum": min(values),
            "maximum": max(values),
            "peak_to_peak": max(values) - min(values),
            "p01": percentile(values, 0.01),
            "median": percentile(values, 0.5),
            "p99": percentile(values, 0.99),
            "linear_drift_per_s": linear_slope(times, values) if times else None,
            "saturation_count": sat_count,
            "saturation_fraction": sat_count / valid_count,
        },
        "limitations": [
            "Standard deviation is a signal statistic, not automatically a baseline-noise estimate.",
            "Packet loss is defensible only when the sequence field and modulus match the protocol.",
            "Drift uses an ordinary least-squares line and is sensitive to transients and peaks.",
        ],
    }

    text = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
