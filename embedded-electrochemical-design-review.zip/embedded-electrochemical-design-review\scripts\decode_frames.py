#!/usr/bin/env python3
"""Decode fixed-layout raw or hex-line UART/BLE frames from a JSON protocol."""

from __future__ import annotations

import argparse
import csv
import json
import struct
from pathlib import Path
from typing import Any

TYPE_FORMATS = {
    "uint8": "B",
    "int8": "b",
    "uint16": "H",
    "int16": "h",
    "uint32": "I",
    "int32": "i",
    "uint64": "Q",
    "int64": "q",
    "float32": "f",
    "float64": "d",
}


def crc16_modbus(data: bytes) -> int:
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if crc & 1 else crc >> 1
    return crc


def checksum(data: bytes, algorithm: str) -> int:
    if algorithm == "sum8":
        return sum(data) & 0xFF
    if algorithm == "xor8":
        value = 0
        for byte in data:
            value ^= byte
        return value
    if algorithm == "crc16_modbus":
        return crc16_modbus(data)
    raise ValueError(f"unsupported checksum algorithm: {algorithm}")


def load_stream(path: Path, encoding: str) -> bytes:
    if encoding == "raw":
        return path.read_bytes()
    chunks = []
    for number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        cleaned = "".join(line.split()).replace("0x", "")
        if not cleaned:
            continue
        try:
            chunks.append(bytes.fromhex(cleaned))
        except ValueError as exc:
            raise ValueError(f"invalid hex at line {number}") from exc
    return b"".join(chunks)


def frame_offsets(stream: bytes, frame_length: int, sync: bytes) -> tuple[list[int], int]:
    offsets = []
    cursor = 0
    discarded = 0
    while cursor + frame_length <= len(stream):
        if sync:
            found = stream.find(sync, cursor)
            if found < 0 or found + frame_length > len(stream):
                discarded += len(stream) - cursor
                cursor = len(stream)
                break
            discarded += found - cursor
            cursor = found
        offsets.append(cursor)
        cursor += frame_length
    discarded += len(stream) - cursor
    return offsets, discarded


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("protocol", type=Path)
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--output-csv", type=Path)
    args = parser.parse_args()

    cfg: dict[str, Any] = json.loads(args.protocol.read_text(encoding="utf-8"))
    frame_length = int(cfg["frame_length"])
    if frame_length <= 0:
        raise ValueError("frame_length must be positive")
    stream = load_stream(args.input, cfg.get("input_encoding", "hex-lines"))
    sync = bytes.fromhex(cfg.get("sync_hex", ""))
    offsets, discarded = frame_offsets(stream, frame_length, sync)
    default_endian = cfg.get("endianness", "little")
    rows = []
    checksum_failures = 0

    for index, offset in enumerate(offsets):
        frame = stream[offset : offset + frame_length]
        row: dict[str, Any] = {"frame_index": index, "byte_offset": offset, "valid": True}
        for field in cfg.get("fields", []):
            field_type = field["type"]
            if field_type not in TYPE_FORMATS:
                raise ValueError(f"unsupported field type: {field_type}")
            endian = field.get("endianness", default_endian)
            prefix = "<" if endian == "little" else ">"
            fmt = prefix + TYPE_FORMATS[field_type]
            position = int(field["offset"])
            size = struct.calcsize(fmt)
            if position < 0 or position + size > frame_length:
                raise ValueError(f"field {field['name']} exceeds frame")
            raw_value = struct.unpack_from(fmt, frame, position)[0]
            row[field["name"]] = raw_value * float(field.get("scale", 1.0)) + float(field.get("add", 0.0))

        crc_cfg = cfg.get("checksum")
        if crc_cfg:
            algorithm = crc_cfg["algorithm"]
            start = int(crc_cfg.get("start", 0))
            end = int(crc_cfg["end"])
            stored_offset = int(crc_cfg["stored_offset"])
            stored_size = int(crc_cfg.get("stored_size", 2 if algorithm == "crc16_modbus" else 1))
            stored_endian = crc_cfg.get("endianness", default_endian)
            stored = int.from_bytes(frame[stored_offset : stored_offset + stored_size], stored_endian)
            calculated = checksum(frame[start:end], algorithm)
            row["checksum_stored"] = stored
            row["checksum_calculated"] = calculated
            row["checksum_ok"] = stored == calculated
            row["valid"] = bool(row["checksum_ok"])
            if not row["valid"]:
                checksum_failures += 1
        rows.append(row)

    result = {
        "protocol": str(args.protocol),
        "input": str(args.input),
        "bytes_total": len(stream),
        "frame_length": frame_length,
        "frames_decoded": len(rows),
        "valid_frames": sum(bool(row["valid"]) for row in rows),
        "checksum_failures": checksum_failures,
        "discarded_or_trailing_bytes": discarded,
        "frames": rows,
    }

    text = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)

    if args.output_csv and rows:
        args.output_csv.parent.mkdir(parents=True, exist_ok=True)
        fieldnames = list(dict.fromkeys(key for row in rows for key in row))
        with args.output_csv.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
