# PCB Layout Review

## Contents

1. Evidence requirements
2. Placement and partitioning
3. Ground and return paths
4. High-impedance and low-current nodes
5. Converters, clocks, and digital buses
6. Power, references, and decoupling
7. Manufacturability and verification

## 1. Evidence requirements

Prefer copper-layer plots, board stackup, component coordinates, and net names. A component-side screenshot alone cannot prove return paths or plane continuity. Mark hidden-layer judgments unresolved.

## 2. Placement and partitioning

Place by signal flow and sensitivity. Keep electrode connector, protection, TIA, feedback network, low-noise gain/filter, ADC, and reference compact. Keep radios, switching regulators, crystals, fast clocks, PWM, and high-current CE routes away from WE/RE/TIA nodes.

## 3. Ground and return paths

Analyze where current returns. Prefer a continuous low-impedance plane unless the exact converter or manufacturer reference design requires another scheme. Do not create a split that forces SPI or clock return around a gap. Connect AGND, DGND, exposed pads, chassis, shield, and isolated grounds according to the exact datasheet and safety architecture.

## 4. High-impedance and low-current nodes

- Minimize WE, RE, TIA summing-node, and feedback-loop length and area.
- Avoid vias, test pads, solder-mask openings, and contaminated surfaces where leakage matters.
- Keep high-impedance nets away from clocks, SPI, PWM, antennas, and CE drive.
- Use guarding only when the guard can be driven near the sensitive-node potential and remains stable.
- Evaluate connector leakage, ESD-device leakage/capacitance, flux residue, humidity, and board material.
- Place RTIA/CTIA at the amplifier pins with a compact return.

## 5. Converters, clocks, and digital buses

Place ADC input filters at ADC pins and keep differential paths balanced when required. Keep reference loops compact. Route clocks and fast edges with uninterrupted return paths; add source damping only when justified. Do not route digital lines through the analog input or reference region.

## 6. Power, references, and decoupling

- Place the smallest high-frequency capacitor at each supply pin with minimal loop area.
- Connect regulator/reference capacitors exactly as required, including ESR constraints.
- Separate noisy power conversion physically from the analog front end.
- Avoid sharing long narrow traces between a reference return and high-current loads.
- Verify copper width, thermal rise, regulator dissipation, and exposed-pad thermal vias.

## 7. Manufacturability and verification

Check footprint dimensions, pin-1 marking, courtyard, assembly access, polarity, creepage where relevant, electrode connector labeling, shield connection, and test points. Provide safe test access to rails, references, command, RE feedback, CE output, TIA output, ADC input, reset, clock, and buses without adding excessive capacitance to sensitive nodes.

For every issue state actual location, affected net, datasheet or physical principle, consequence, recommended geometry, and a measurement or inspection that closes the issue.
