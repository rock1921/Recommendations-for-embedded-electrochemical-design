---
name: embedded-electrochemical-design-review
description: Audit embedded electrochemical instruments from schematics, netlists, BOMs, component datasheets, PCB images, firmware scaling, UART or BLE captures, and bench measurements. Use for three-electrode potentiostat logic checks; component pin, supply, peripheral, and layout compliance; voltage, current, impedance, gain, noise, bandwidth, saturation, ADC/DAC accuracy, and uncertainty calculations; serial/BLE integrity analysis; oscilloscope and multimeter test planning; and generation of a traceable Word report named "Recommendations for embedded electrochemical design.docx" on the user's Desktop.
---

# Embedded Electrochemical Design Review

Perform an evidence-based, device-independent review of an embedded electrochemical design. Keep electrochemical control logic, analog calculations, digital data integrity, bench verification, and component datasheet compliance in one traceable review model.

## Operating principles

- Treat the submitted schematic, netlist, BOM, exact orderable part numbers, package drawings, datasheets, firmware, logs, and measurements as separate evidence sources.
- Prefer an official manufacturer datasheet supplied by the user. If absent, retrieve only the official manufacturer document and record its revision and URL.
- Never substitute a family member, package, or datasheet revision without declaring it.
- Distinguish required, recommended, typical, application-specific, and absolute-maximum statements.
- Do not use absolute maximum ratings as normal operating limits.
- Do not invent a net connection from an unreadable image. Mark it `UNRESOLVED` and request a vector PDF, netlist, or clearer crop.
- Do not call resistance impedance unless frequency and reactive components are included.
- Do not call theoretical circuit noise a sensor LOD. LOD and LOQ require blank measurements and a stated statistical method.
- Preserve sign conventions. State whether potential means `E_WE - E_RE`, and derive current polarity from the actual TIA topology and software conversion.
- Attach an evidence grade to every material conclusion: `A` direct multi-source confirmation, `B` datasheet plus schematic derivation, `C` nominal calculation, or `D` unresolved assumption.
- Separate observed facts, calculated results, inferences, and recommendations.

## Workflow

### 1. Inventory the evidence

Create a component and file manifest before judging the circuit. Record exact MPN, manufacturer, package, schematic symbol, footprint, datasheet revision/date, relevant pages, and whether the source is official.

Read [references/workflow-and-evidence.md](references/workflow-and-evidence.md). Use its normalized review model. List missing inputs and continue with bounded assumptions when safe.

### 2. Reconstruct functional blocks

Identify, without assuming a particular chip family:

1. excitation or DAC path;
2. potentiostat control amplifier and counter-electrode drive;
3. reference-electrode sensing path;
4. working-electrode current path and TIA;
5. gain, filtering, biasing, ADC, reference, and protection;
6. MCU, clocks, reset, UART/SPI/I2C/BLE, power domains, and connectors.

Read [references/potentiostat-logic.md](references/potentiostat-logic.md). Trace the loop from the requested `E_WE-RE` through the control amplifier to CE and back through RE. Trace WE current independently through the measurement path.

### 3. Audit every component against its datasheet

Read [references/component-datasheet-review.md](references/component-datasheet-review.md). Produce a per-pin compliance matrix and a per-component design note covering:

- supply range, sequence, grounding, exposed pad, decoupling, and references;
- common-mode range, output swing, drive, stability, timing, and loading;
- required passives, reset/strap/address pins, unused pins, NC versus DNC;
- digital thresholds, bus pull-ups, clocks, startup state, and protection;
- exact package pinout and footprint orientation;
- manufacturer layout instructions and evaluation-board differences.

Cite page, table, figure, or section for every P0/P1 finding.

### 4. Calculate operating points and performance

Read [references/analog-analysis.md](references/analog-analysis.md) and [references/converter-accuracy.md](references/converter-accuracy.md).

Build the complete transfer chain:

`electrode current -> TIA -> gain/filter -> ADC -> code -> firmware units`

Also build the excitation chain:

`requested E_WE-RE -> firmware value -> DAC code -> analog level -> control-loop polarity -> actual E_WE-RE`

Calculate only from sourced values. Include DC operating points, frequency-dependent impedance, full-scale current, pole frequencies, settling, noise, headroom, ADC/DAC utilization, quantization, ENOB-limited resolution, and an uncertainty budget. Use `scripts/calculate_signal_chain.py` for deterministic arithmetic.

### 5. Analyze UART or BLE data

Read [references/serial-ble-analysis.md](references/serial-ble-analysis.md).

- Reconstruct complete application frames before interpreting samples.
- Verify endianness, signedness, scaling, timestamps, sequence continuity, CRC/checksum, fragmentation, duplication, and overflow behavior.
- Preserve raw data and decode into a separate artifact.
- Use `scripts/decode_frames.py` for documented binary layouts.
- Use `scripts/analyze_stream.py` for sequence, timing, saturation, noise, and drift metrics.
- Do not infer missing packet bytes or silently interpolate formal measurement data.

### 6. Generate an executable bench plan

Read [references/bench-measurement.md](references/bench-measurement.md). For each rail and critical node, state:

- instrument and probe mode;
- reference point and grounding risk;
- expected nominal, minimum, maximum, tolerance basis, and waveform;
- power-on or experiment state;
- pass/fail criterion;
- diagnostic meaning of high, low, clipped, oscillating, noisy, or floating readings.

Default a scope to a 10x, 1 Mohm probe for high-impedance analog nodes. Never recommend 50 ohm termination unless the source and transmission line are designed for it. Warn that a grounded bench-scope clip may short a floating or negative rail.

### 7. Audit PCB layout

Read [references/pcb-layout.md](references/pcb-layout.md). Compare the actual PCB against manufacturer placement and routing guidance. Review current return paths rather than mechanically demanding a split or star ground. Prioritize high-impedance WE/RE/TIA nodes, feedback-loop area, references, decoupling loops, ADC inputs, clock/SPI coupling, leakage contamination, guarding, shielding, electrode protection, and test access.

### 8. Prioritize and report

Assign:

- `P0`: damage, unsafe test connection, invalid potentiostat topology, electrode short, or guaranteed invalid data;
- `P1`: likely saturation, instability, range violation, severe timing/data-integrity fault, or missing required datasheet circuit;
- `P2`: material noise, accuracy, layout, calibration, robustness, or maintainability limitation;
- `P3`: optional optimization or documentation improvement.

For each finding include location, observation, requirement, consequence, corrective action, verification step, evidence grade, and citation.

Normalize the review to [references/report-model.md](references/report-model.md), then run:

```bash
python scripts/generate_report.py review.json
```

The default output must be the actual Windows Desktop path with the exact filename:

```text
Recommendations for embedded electrochemical design.docx
```

Use `--output` only when the user explicitly requests another location. Render the generated DOCX to page images using an available document-rendering tool, inspect every page for clipping, overlap, broken tables, missing glyphs, and blank pages, then remove intermediate renders.

## Required report contents

Include all applicable sections:

1. Executive summary and review status
2. Submitted evidence and assumptions
3. Electrochemical topology and sign convention
4. Component/datasheet compliance matrices
5. Power rails and DC operating points
6. Voltage, current, impedance, gain, bandwidth, and saturation
7. Noise, resolution, accuracy, and uncertainty budget
8. ADC/DAC and firmware conversion audit
9. UART/BLE integrity analysis
10. Oscilloscope and multimeter measurement plan
11. PCB layout review
12. P0/P1/P2/P3 recommendations and acceptance criteria
13. Unresolved items and residual risk
14. Datasheet and technical references

## Completion gate

Do not state that a design is compliant until:

- exact components and packages are identified;
- all P0/P1 items are resolved or explicitly accepted;
- calculations expose units, assumptions, and source values;
- potentiostat polarity and electrode paths are verified;
- converter limits and software scaling agree;
- data integrity metrics are reported when captures exist;
- the bench plan contains safe references and measurable limits;
- the Word report is generated and visually checked.
