# Oscilloscope and Multimeter Test Planning

## Contents

1. Safety gate
2. Instrument defaults
3. Measurement sequence
4. Expected-value records
5. Diagnostic patterns

## 1. Safety gate

Before attaching a grounded bench oscilloscope, determine whether probe ground is bonded to protective earth and whether the device under test is floating. Never clip ground to a negative rail, bridge node, electrode, or isolated domain without confirming the consequence. Use an appropriate differential or isolated probe when required.

Do not perform resistance or continuity measurements on a powered circuit. Discharge capacitors first.

## 2. Instrument defaults

For high-impedance analog nodes use a compensated 10x probe and 1 Mohm scope input. Use 50 ohm termination only for a source and transmission line designed to drive 50 ohm. Start with DC coupling to preserve bias. Enable bandwidth limiting when measuring low-frequency noise and record the bandwidth.

Use a DMM with adequate input impedance for DC rails and bias nodes. Do not load a reference-electrode input with an unsuitable meter.

## 3. Measurement sequence

1. Power off: inspect resistance to ground and rail shorts.
2. Power on without electrodes: verify rails, internal regulators, references, reset, and clocks.
3. Verify digital buses at the source and target pins.
4. Verify DAC/static command levels.
5. Apply a passive dummy cell and verify RE tracking, CE headroom, TIA polarity, and ADC conversion.
6. Exercise step, ramp, triangle, and pulse waveforms appropriate to implemented methods.
7. Connect a real cell only after P0/P1 bench criteria pass.

## 4. Expected-value records

For each test point report:

```text
node, state, instrument, probe, reference node, nominal,
minimum, maximum, waveform, tolerance basis, pass/fail,
grounding warning, failure interpretation
```

Derive bounds from datasheet limits, resistor tolerance, reference error, and calculated operating point. Do not use arbitrary percentages when a specified limit exists.

## 5. Diagnostic patterns

- rail low with high current: short, overload, wrong regulator, or startup latch;
- reference noisy: poor decoupling, digital return coupling, overload, or probing artifact;
- CE clipped: insufficient compliance, excessive current, wrong bias, or control polarity;
- RE not tracking: open RE, wrong feedback, amplifier saturation, or unstable loop;
- TIA at a rail: excessive current, wrong sign, open feedback, or invalid common mode;
- periodic high-frequency oscillation: loop stability, decoupling, capacitive load, or probe ground;
- all nodes show the same waveform: ground/reference error, severe supply coupling, or measurement setup error;
- ADC code random/full-scale: floating input, framing error, reference failure, or sign/byte-order bug.

Treat these as hypotheses and specify the next discriminating measurement.
