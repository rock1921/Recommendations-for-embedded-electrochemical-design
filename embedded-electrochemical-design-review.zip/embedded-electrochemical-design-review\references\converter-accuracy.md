# ADC, DAC, and Firmware Conversion Audit

## 1. ADC checks

Determine the actual transfer function from the selected reference, input mode, PGA, coding format, and data width. Do not assume all bipolar converters use the same endpoint convention.

At minimum verify:

- reference magnitude and polarity;
- differential and common-mode input ranges;
- code format: offset binary, straight binary, or two's complement;
- sign extension into the MCU type;
- status/CRC bytes excluded from the sample word;
- data-rate and filter latency;
- PGA and reference-buffer restrictions;
- calibration coefficients and reset behavior;
- firmware constants, units, and floating/integer overflow.

When the transfer is known, report ideal LSB and ENOB-limited RMS scale separately:

```text
ideal_lsb = full_scale_span / 2^N
enob_lsb = full_scale_span / 2^ENOB
quantization_rms = ideal_lsb / sqrt(12)
```

## 2. DAC checks

Verify the exact code equation, reference source, gain mode, output buffer, offset, monotonic range, and load. Derive the entire excitation transfer through any level shift or inversion. Check the minimum and maximum instantaneous waveform, including SWV/DPV pulses.

Distinguish:

- requested electrochemical potential;
- DAC pin voltage;
- control-amplifier command voltage;
- measured `E_WE-E_RE`.

## 3. Firmware checks

- Use explicit-width signed integer types for converter words.
- Sign-extend before arithmetic.
- Avoid unsigned subtraction around a bias code.
- Keep calibration coefficients versioned with hardware gain settings.
- Record raw code alongside converted values.
- Include saturation and invalid-status flags in exported data.
- Test transfer endpoints, zero, one LSB either side of zero, and negative full-scale representations.

## 4. Accuracy budget

Include reference initial error and drift, ADC/DAC gain and offset, INL where relevant, amplifier offset/bias, resistor tolerance/TCR, noise, quantization, and calibration uncertainty. Do not combine guaranteed maximum errors with typical RMS terms without labeling the method.
