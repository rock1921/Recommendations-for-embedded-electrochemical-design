# Component and Datasheet Compliance

## Contents

1. Identity and source control
2. Per-pin matrix
3. Component-specific checks
4. Reference-design comparison
5. Citation rules

## 1. Identity and source control

Record the complete MPN, package code, temperature grade, revision, publication date, and official URL. Verify symbol pin numbers against the exact package. Flag a generic symbol, unverified footprint, or family-level datasheet as unresolved.

Check errata before accepting a register behavior or timing limit. When a datasheet and evaluation board differ, determine whether the evaluation board targets a different operating mode, frequency, sensor type, or optional population.

## 2. Per-pin matrix

For every pin record:

- pin number and mnemonic;
- electrical type and power domain;
- schematic net and connected components;
- required or allowed connection;
- voltage/current/timing limits;
- startup and inactive state;
- status: compliant, noncompliant, not applicable, or unresolved;
- exact evidence citation.

Treat these labels differently:

- `NC`: no internal connection, but follow package-specific guidance.
- `DNC`: do not connect.
- `EP/PAD`: often requires ground and thermal vias; verify exact instruction.
- `REF/CAP/REG`: often a decoupling or regulator-output node, not an external supply input.
- open-drain/open-collector: requires a valid pull-up domain.

## 3. Component-specific checks

### Op amps and instrumentation amplifiers

Check supply range, input common mode, differential input limit, output swing versus load, input/output phase reversal, offset, bias current, noise density, gain bandwidth, slew rate, capacitive-load stability, gain-setting equation, feedback compensation, shutdown pins, and power-on behavior.

### ADCs

Check analog/digital supplies, reference source and decoupling, absolute and recommended input range, common mode, differential range, PGA restrictions, source impedance, input settling, anti-alias network, data rate, digital filter latency, clock, reset, DRDY, SPI mode, CRC/status bytes, calibration, and unused inputs.

### DACs

Check reference input/output role, code transfer equation, output range, buffer load, capacitive stability, settling, power-on code, latch/update timing, SPI/I2C format, LDAC/CS behavior, monotonicity, and output filtering.

### Electrochemical AFEs

Check electrode pin roles, internal switch matrix, TIA choices, bias/zero DAC ranges, reference/current paths, external RTIA/CTIA requirements, compensation nodes, wake-up timing, calibration resistor, sequencer timing, and electrode protection.

### Regulators and references

Check input/output range, dropout, current, stability capacitor and ESR, noise, PSRR versus frequency, thermal rise, reverse current, enable state, soft start, sequencing, and reference load/decoupling.

### Digital interfaces and radios

Check I/O voltage, VIH/VIL and VOH/VOL compatibility, pull-ups, bus capacitance, SPI mode and speed, reset/boot straps, antenna keepout, RF ground, coexistence, packet size, and flow control.

### Passives and protection

Check tolerance, temperature coefficient, voltage coefficient, dielectric absorption, leakage, power rating, working voltage, pulse rating, ESD capacitance, clamp current, and how protection leakage affects high-impedance nodes.

## 4. Reference-design comparison

Compare the submitted circuit against both the mandatory datasheet circuit and the official evaluation board. Classify every difference as:

- intentional and justified;
- optional population difference;
- operating-mode difference;
- unresolved;
- noncompliant.

Do not copy an evaluation-board value without checking the intended bandwidth, sensor impedance, and gain.

## 5. Citation rules

For P0/P1 issues cite `document, revision, page, table/figure/section`. Quote minimally and paraphrase accurately. Mark typical graphs as characterization, not guaranteed production limits. When a value is computed, cite every source parameter and show the formula.
