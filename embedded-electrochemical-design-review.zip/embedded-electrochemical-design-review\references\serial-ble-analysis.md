# UART and BLE Data Integrity

## Contents

1. Evidence preservation
2. Frame reconstruction
3. Numeric decoding
4. Integrity metrics
5. Electrochemical context

## 1. Evidence preservation

Keep the original byte stream immutable. Save parser configuration and decoded output separately. Record UART baud/parity/stop bits or BLE service, characteristic, MTU, notification mode, and timestamps when available.

## 2. Frame reconstruction

- Parse only complete frames defined by the protocol.
- Handle BLE fragmentation and multiple application frames in one notification.
- Bound receive buffers and report overflow/resynchronization.
- Validate length before field access.
- Verify CRC/checksum over the documented byte range.
- Reject or quarantine malformed frames; do not silently repair them.

## 3. Numeric decoding

Verify field offset, width, endianness, signedness, floating-point format, scale, offset, and unit. For ADC codes, verify sign extension before calibration. Test known vectors such as `0x000000`, positive one, negative one, maximum positive, and minimum negative.

## 4. Integrity metrics

Report:

- total, valid, invalid, and CRC-failed frames;
- duplicate and missing sequence numbers;
- out-of-order and wrong-run frames;
- effective sample rate and timestamp jitter;
- saturation percentage;
- baseline mean, standard deviation, RMS, peak-to-peak, and linear drift;
- interruption and partial-run status.

Do not estimate packet loss from sample count alone when sequence numbers or expected count are unavailable.

## 5. Electrochemical context

Retain method, run ID, cycle, segment, direction, potential, current, raw ADC code, calibration version, and timing fields when available. A smooth curve is not proof of valid framing. Do not perform formal peak or concentration analysis on incomplete, duplicated, saturated, or unit-ambiguous data.
