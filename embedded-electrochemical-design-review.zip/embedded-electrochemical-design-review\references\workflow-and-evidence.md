# Workflow and Evidence Model

## Contents

1. Input hierarchy
2. Normalized review model
3. Evidence grades
4. Missing-information behavior
5. Review states

## 1. Input hierarchy

Prefer evidence in this order for electrical facts:

1. exact official datasheet and package drawing;
2. official errata and application notes;
3. official evaluation-board schematic and layout;
4. submitted netlist, BOM, schematic, PCB, and source code;
5. measured data with a documented setup;
6. distributor pages, forum posts, and unsourced diagrams.

Lower-ranked sources may explain but must not override a higher-ranked source without documenting an erratum or application-specific reason.

## 2. Normalized review model

Build `review.json` with these top-level keys. Omit unavailable optional sections instead of inventing content.

```json
{
  "metadata": {},
  "executive_summary": [],
  "inputs": [],
  "assumptions": [],
  "electrochemical_topology": {},
  "component_reviews": [],
  "operating_points": [],
  "calculations": [],
  "data_quality": {},
  "measurements": [],
  "layout_findings": [],
  "recommendations": [],
  "unresolved": [],
  "references": []
}
```

Use SI units in machine-readable fields. Add a human-readable display value only for presentation.

Every finding should support:

```json
{
  "id": "P1-003",
  "priority": "P1",
  "title": "ADC input exceeds common-mode range",
  "location": "U4 AINP",
  "observation": "...",
  "requirement": "...",
  "consequence": "...",
  "recommendation": "...",
  "verification": "...",
  "evidence_grade": "B",
  "citations": ["U4 datasheet Rev X, Table Y, p. 12"]
}
```

## 3. Evidence grades

- `A`: confirmed by at least two independent primary artifacts, such as netlist plus official datasheet, or firmware plus measured waveform.
- `B`: directly derived from one primary artifact and a transparent calculation.
- `C`: estimate using nominal or typical values with declared assumptions.
- `D`: unresolved interpretation, low-quality image, missing revision, or unsupported secondary source.

Never promote a grade because a conclusion seems likely.

## 4. Missing-information behavior

- Continue with safe, bounded calculations when a missing value can be represented as a range.
- Produce separate typical and worst-case results when both are available.
- Stop a definitive pinout or safety conclusion when package, reference ground, or supply domain is unknown.
- Request a netlist when crossings, junction dots, or hierarchical labels are unreadable.
- Request raw data rather than screenshots for quantitative noise, drift, or packet-loss analysis.

## 5. Review states

- `PASS`: all applicable requirements verified and no open P0/P1 items.
- `CONDITIONAL`: no known P0 item, but unresolved assumptions or P1 verification remain.
- `FAIL`: one or more P0 items or a proven violation that invalidates the intended measurement.
- `INSUFFICIENT_EVIDENCE`: artifacts do not support a defensible conclusion.

Do not use `PASS` for a partial schematic or a board with no identified package variants.
