# Analog Signal-Chain Analysis

## Contents

1. Units and signs
2. TIA impedance and range
3. Noise
4. Bandwidth and settling
5. Headroom and stability
6. Uncertainty

## 1. Units and signs

Convert inputs to SI units before calculation. Keep a unit-bearing display value in reports. State current polarity at WE and the TIA equation used.

## 2. TIA impedance and range

For parallel `Rf` and `Cf`:

```text
Zf(f) = Rf / (1 + j*2*pi*f*Rf*Cf)
fp = 1 / (2*pi*Rf*Cf)
Vout = Vbias - Iwe*Zf
```

At DC, estimate usable current range from the smaller output headroom:

```text
Ipositive_max = (Vbias - Vout_min) / Rf
Inegative_max = (Vout_max - Vbias) / Rf
```

Include downstream voltage gain and offset before comparing with ADC limits.

## 3. Noise

For bandwidth `B`, resistor thermal-noise RMS values are:

```text
vn_R = sqrt(4*k*T*Rf*B)
in_R = sqrt(4*k*T*B/Rf)
```

An initial input-referred estimate may combine:

```text
in_total ~= sqrt(in_opamp^2 + (en_opamp/|Zf|)^2 + in_R^2)
```

Label this estimate incomplete unless noise gain, sensor capacitance, op-amp voltage-noise shape, 1/f corners, reference noise, ADC noise, and filter transfer functions are modeled. Integrate spectral density through the actual noise bandwidth when adequate data exists.

Never multiply a spot noise density by `sqrt(sample rate/2)` when a digital/analog filter defines a narrower ENBW.

## 4. Bandwidth and settling

Calculate all analog poles and identify the dominant one. For a first-order response, use approximately:

```text
t_0.1_percent ~= 6.9*tau
t_0.01_percent ~= 9.2*tau
```

Do not apply a first-order result to an underdamped loop. Compare DAC settling, control-loop settling, TIA settling, ADC acquisition, digital-filter latency, and firmware delay with the requested sampling instant.

## 5. Headroom and stability

Check every op-amp input against its common-mode limits under min/max supplies and signal extremes. Check outputs against load-dependent swing, not rail labels. Include CE solution drop, transient currents, and protection resistor drops.

For stability, review feedback-loop area, capacitive load, feedback capacitance, sensor capacitance, gain/noise-gain constraints, and manufacturer phase-margin guidance. Do not claim a numeric phase margin without a loop model or measurement.

## 6. Uncertainty

Separate:

- resolution: smallest code or noise-limited distinguishable increment;
- accuracy: closeness after all systematic errors;
- precision: repeatability;
- uncertainty: stated interval and assumptions.

Use root-sum-square only for independent random terms. Use worst-case sums for bounded correlated tolerances when appropriate. Report nominal, typical estimate, worst case, and calibrated estimate separately.
